export default function Terms(){
  return (
    <div className="container py-12 prose max-w-none">
      <h1>Terms of Use</h1>
      <p>Placeholder. Replace with your terms.</p>
    </div>
  );
}
