export default function Privacy(){
  return (
    <div className="container py-12 prose max-w-none">
      <h1>Privacy Policy</h1>
      <p>Placeholder. Replace with your policy.</p>
    </div>
  );
}
