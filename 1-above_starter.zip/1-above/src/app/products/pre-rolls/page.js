import ProductGrid from "@/components/ProductCard";
export const metadata = { title: "Pre-rolls | 1 Above" };
export default function Page(){ return <ProductGrid category="preroll" /> }
