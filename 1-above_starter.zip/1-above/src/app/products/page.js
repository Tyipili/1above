import ProductGrid from "@/components/ProductCard";
export const metadata = { title: "Products | 1 Above" };
export default function ProductsPage() { return <ProductGrid category="all" /> }
