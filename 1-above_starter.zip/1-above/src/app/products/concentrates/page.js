import ProductGrid from "@/components/ProductCard";
export const metadata = { title: "Concentrates | 1 Above" };
export default function Page(){ return <ProductGrid category="concentrate" /> }
