import ProductGrid from "@/components/ProductCard";
export const metadata = { title: "Vapes | 1 Above" };
export default function Page(){ return <ProductGrid category="vape" /> }
